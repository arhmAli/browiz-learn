%robust PID control
% K=1(tau+1)^2
clear all
close all
clc

kd = 12; 
kp = 137.6; 
ki = 512; 

k = ureal('k', 1.5, 'PlusMinus', 0.5);
r = ureal('r', 0.75, 'PlusMinus', 0.25);
sys = tf([k], [r*r 2*r 1]);

Gc = tf([kd kp ki], [1 0]);
loop = series(Gc, sys);
cl_loop = feedback(loop, 1);

Gp = tf([42.67], [1 11.38 42.67]); % Updated plant transfer function

final = series(Gp, cl_loop);

% Display step response information for the nominal system
stepInfoNominal = stepinfo(getNominal(final));
disp('Step Response Information for Nominal System:')
disp(stepInfoNominal)

% Plot the step response for the nominal system and the sampled uncertainty
figure
step(final, getNominal(final))
legend('sampled uncertainty', 'nominal')
title('Step Response')
