%% 
clear all;
clc;
close all;
num = 1;
den = [10 1];
sys = tf(1,[10 1]);
% using zero order hold
sys1 = c2d(sys,4,'zoh'); % CT to DT with Ts 4
sys2 = c2d(sys,0.5,'zoh');% CT to DT with Ts 0.5
% using tustin transformation
sys3 = c2d(sys,4,'tustin'); % CT to DT with tustin method by Ts 4
% Responses
step(sys)
hold on
step(sys1)
hold on
step(sys2)
hold on
step(sys3)
hold on
legend('CT to DT with Ts 4','CT to DT with Ts 0.5',' CT to DT with tustin method by Ts 4');


% Now design a PID conttroller for this
figure
sys1=c2d(sys,0.1,'zoh');
Kp=4
Ki=2
Kd=5
Tf=1
Ts=0.1
C=pid(Kp,Ki,Kd,Tf,Ts,'IFormula','Trapezoidal','Dformula','Trapezoidal');
Gp=series(C,sys1)
clos=feedback(Gp,1)
step(clos)