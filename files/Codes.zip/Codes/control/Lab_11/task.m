clc;
clear all;
sys=tf([1],[1 10 20]);
kd=33.75; kp=1323.75; ki=15625;
Gc=tf([kd kp ki],[1 0]);
loop=series(Gc,sys)
cl_loop=feedback(loop,1)
Gp=tf([462.96],[1 39.22 462.96]); 
final=series(Gp,cl_loop)
stepinfo(getNominal(final))
figure(1)
hold on
step(final,getNominal(final))
legend('Sampled Uncertanity','Nominal')
sys3=c2d(final,0.1,'zoh');
sys4=c2d(final,0.01,'zoh');

hold on
step(sys3)
legend('ZOH with Ts 0.1')
hold on
step(sys4)
legend('ZOH with Ts 0.01')