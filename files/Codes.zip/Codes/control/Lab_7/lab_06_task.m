clc;
clear all;
close all
% Parameter Values
l = 0.5;
m = 0.3;
I = (1/3)*m*l*l;
% b = 0;
M = 2.5;
g = 9.8;
R = 0.2;
rm = 0.05;
Kg = 5;
Kt = 1.6*10^-2;
Ke = 1.6*10^-2;
J = 3.98*10^-7;
Bd = 0;
% For A,B,C and D Matrices
h1 = M+m+J*Kg/rm^2;
h2 = (Kt*Kg^2*Ke)/(rm^2*R) + (Bd*Kg)/rm^2;
h3 = Kt*Kg/(rm*R);
h4 = h1 - (m^2*l^2)/(I+m*l^2);
h5 = (I+m*l^2)/(m*l);
% Matrix A
a22 = -h2/h4;
a23 = (m^2*g*l^2)/(h4*(I+m*l^2));
a42 = -h2/(h1*h5-m*l);
a43 = h1*g/(h1*h5-m*l);
A = [0 1 0 0;20.601 0 0 0;0 0 0 1;-0.4905 0 0 0];
% Matrix B
b42 = h3/h4;
b44 = h3/(h1*h5-m*l);
B = [0;-1;0;0.5];
% Matrix C
C = [0 0 1 0];
% Matrix D
D = 0;
% Open Loop State-Space System
sys_open = ss(A,B,C,D);
% to check controllablity
Pc = ctrb(A,B);
% find determinent
det_Pc = det (Pc);
% check wheteher system is controllable or not
if det_Pc == 0
    disp('System is not Controllable')
else
    disp('System is Controllable')
end
% for step response plot
S = stepinfo(sys_open);
% subplot(2,2,1)
figure
step(sys_open);
title('\bf Open-Loop Response')
% Calculating Loop Gains Using Acker's Formula
[b,a] = ss2tf(A,B,C,D);
[mc,n] = size(A);
Ahat = [A zeros(mc,1); -C 0];
Bhat = [B; 0];
desPols1=[-1+13*i;-1-13*i;-5;-5;-5];
Khat = acker(Ahat, Bhat, desPols1);
[q,r] = size(Khat);
K = [Khat(1:r-1)];
ki = -Khat(1,r);

%Responses
A_bar = [A-B*K B*ki; -C 0];
B_bar = [0; 0; 0; 0; 1];
D_bar = 0;
C_bar = eye(5);
sys2 = ss(A_bar, B_bar, C_bar, D_bar);
data = step(sys2);

figure(2)
%u is the input force required to the system to balance the pendulam
u = -K(1).*data(:,1) - K(2).*data(:,2) - K(3).*data(:,3) - K(4).*data(:,4) + ki.*data(:,5);
plot(u)
title('responce of the system with integrator')

figure (3)
subplot(5,1,1)
plot(data(:,1))
title('X(position of cart)')
subplot(5,1,2)
plot(data(:,2))
title('X dot(velocity of cart)')
subplot(5,1,3)
plot(data(:,3))
title('theta')
subplot(5,1,4)
plot(data(:,4))
title('theta_dot')
subplot(5,1,5)
plot(data(:,5))
title('integrator response');

%% Animation 
x=data(:,3);
theta=data(:,1);
figure
for ii=1:length(x)
    clf
    x(ii);
    theta(ii)';
    thy=1*cos(theta(ii))
    thx=1*sin(theta(ii))
    hold on 
    plot([x(ii) -thx+x(ii)],[0 thy]);
    plot([x(ii)-0.1 x(ii)+0.1],[0 0]);
    plot([x(ii)-0.1 x(ii)-0.1],[0 -0.1]);
    plot([x(ii)+0.1 x(ii)+0.1],[0 -0.1]);
    plot([x(ii)-0.1 x(ii)+0.1],[-0.1 -0.1]);
    axis([-0.5 1.5 -0.2 0.7])
    pause(0.003)
end