clear all;
clc
num=1;
den=[1 5 9];
plant=tf(num,den);
step(plant)
s_open=stepinfo(plant)
%closed loop with propotional gain
Kp=50
% contr=Kp;
% sys_cl=feedback(contr*plant,1)
% t=0:0.01:2;
% step(sys_cl,t)
% s=stepinfo(sys_cl)
% %now PD
Kd=5;
% contr=tf([Kd Kp],1)
% sys_cl=feedback(contr*plant,1)
% t=0:0.01:2
% step(sys_cl,t)
% s=stepinfo(sys_cl)
% oscillation lowered and overshoot low
% now we want to remove steady state error
% KI=5;
% contr=tf([Kp KI],[1 0]);
% sys_cl=feedback(contr*plant,1)
% t=0:0.01:2
% step(sys_cl,t)
% s=stepinfo(sys_cl)
% this removed ess but introduced osciallations
KI=5;
Kp=18.4
KI=39.4;
Kd=2.1;
contr=tf([Kd Kp KI],[1 0]);
sys_cl=feedback(contr*plant,1)
t=0:0.01:2
step(sys_cl,t)
s=stepinfo(sys_cl)

Gp=100/s(s+38.9)
