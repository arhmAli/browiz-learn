clear all
clc
num=100;
den=[1 38.9 0];
plant=tf(num,den);
Kp=140;
KI=Kp/20;
contr=tf([Kp KI],[1 0]);
sys_cl=feedback(contr*plant,1)
t=0:0.01:2
step(sys_cl,t)
s=stepinfo(sys_cl)
title(sprintf("At (Kp=%.2f)", Kp))
