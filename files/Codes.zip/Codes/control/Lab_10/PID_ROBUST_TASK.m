clear all
close all
clear all
clc
k = ureal('k',4,'Plusminus',0.5)
p1 = ureal('p1',1,'Plusminus',0.25)
p2 = ureal('p2',4,'Plusminus',0.25)
kd = 15.5; kp = 214; ki = 1000;
sys = tf([k],[1 p1+p2 p1*p2])
Gc = tf([kd kp ki],[1 0]);
loop = series(Gc,sys)
cl_loop = feedback(loop,1)
Gp = tf([64.5],[1 13.806 64.5]);
final=series(Gp,cl_loop)
stepinfo(getNominal(final))
step(final,getNominal(final))
legend('sampled uncertainity','nominal')