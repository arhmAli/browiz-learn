clear all
close all
clc
k = ureal('k',1,'Plusminus',0.5)
r = ureal('r',1,'Plusminus',0.25)
% G=tf([k],[r*r 2*r 1])
% Gc = tf([1],[1])
% loop = series(Gc,G)
% cl_loop = feedback(loop,1)
% step(cl_loop,getNominal(cl_loop),8) 
kd = 15.5; kp = 214; ki = 1000;
sys = tf([k],[r*r 2*r 1])
Gc = tf([kd kp ki],[1 0]);
loop = series(Gc,sys)
cl_loop = feedback(loop,1)
Gp = tf([64.5],[1 13.8 6