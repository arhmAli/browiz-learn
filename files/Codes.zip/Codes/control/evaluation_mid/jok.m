% Transfer Function
num = 325;
den = conv([1 0], conv([1 2], conv([1 -4], [1 5])));

% Convert to State-Space
[A, B, C, D] = tf2ss(num, den);

% Display State-Space Matrices
disp('State-Space Matrices:');
disp('A = '); disp(A);
disp('B = '); disp(B);
disp('C = '); disp(C);
disp('D = '); disp(D);

% Check Controllability
Pc = ctrb(A, B);
detPc = det(Pc);

% Checking Controllability
if detPc == 0
    disp('System is not controllable');
else
    disp('System is controllable');
end
% Desired Response
zeta = 0.1; % 10% overshoot
wn = 4 / (zeta * 1); % wn = 4 / (zeta * Ts), where Ts is settling time

% Desired Poles
polDes = [-4+39.7*1i; -4-39.7*1i; -20; -20];

% Place Controllable Gains
K = acker(A, B, polDes);
disp('Controllable Gains (K):');
disp(K);

% Create Closed-Loop System
sys_Cl = ss(A - B * K, B, C, D);

% Display Step Response
figure;
step(sys_Cl);
title('Step Response with Controllable Gains');
At = [A, zeros(size(A, 1), 1); -C, 0];
Bt = [B; 0];
Ct = [C, 0];

% Desired Poles (including integral control)
polDes = [polDes; -5]; % Assuming integral pole at -5

% Place Controllable Gains with Integral Control
K = acker(At, Bt, polDes);

% Display Controllable Gains (including integral control)
disp('Controllable Gains with Integral Control (K):');
disp(K);

% Create Closed-Loop System with Integral Control
Acl = At - Bt * K;
sys_cl = ss(Acl, Bt, Ct, 0);

% Display Step Response
figure;
step(sys_cl);
title('Step Response with Controllable Gains and Integral Control');
% Plot Internal States
figure;
initial(sys_cl, zeros(size(Acl, 1), 1), 0.1);
title('Internal States of Closed-Loop System');
