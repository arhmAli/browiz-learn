% Given Transfer Function
numerator = 325;
denominator = conv([1 0], conv([1 2], conv([1 -4], [1 5])));

% Convert to State-Space
[Ac, Bc, Cc, Dc] = tf2ss(numerator, denominator);

% Check Controllability
Pc_task1 = ctrb(Ac, Bc);
det_Pc_task1 = det(Pc_task1);

% Controllability Check
if det_Pc_task1 == 0
    disp('Task 1: System is not Controllable')
else
    disp('Task 1: System is Controllable')
end

% Desired Specifications
zeta = 0.1;  % 10% overshoot
wn = 4 / (zeta * 1);  % Natural frequency for desired settling time of 1 sec

% Corrected Desired Poles
polDes_task2 = [-4+39.7*1i; -4-39.7*1i; -20; -20];

% Design Controllable Gains
[V, D] = eig(Ac);
K_task2 = acker(Ac, Bc, polDes_task2);

% Transform to Controller Canonical Form
[P_task3, T_task3] = canon(Ac, Bc, Cc, Dc);

% Add Integral in the Plant
At_task3 = [Ac, zeros(size(Ac, 1), 1); -Cc, 0];
Bt_task3 = [Bc; 0];
Br_task3 = [zeros(size(Ac, 1), 1); 1];
Ct_task3 = [Cc, 0];

% Design Controller With Integrator
polDes_task3 = [polDes_task2; -10];  % Additional pole for integral control
K_task3 = acker(At_task3, Bt_task3, polDes_task3);
Aci_task3 = At_task3 - Bt_task3 * K_task3;

% Create State-Space System with Integral Control
sys_cl_task3 = ss(Aci_task3, Br_task3, Ct_task3, 0);

% Plot Internal States of Closed-Loop System
figure;
initial(sys_cl_task3, zeros(size(Aci_task3, 1), 1), linspace(0, 5, 100));
title('Internal States of Closed-Loop System');
xlabel('Time');
ylabel('State Value');
