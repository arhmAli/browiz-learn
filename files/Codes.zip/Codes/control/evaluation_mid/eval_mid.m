clc
clear all
close all

% New numerator and denominator
num = 325;
den = conv([1 0], conv([1 2], conv([1 -4], [1 5])));

[A, B, C, D] = tf2ss(num, den);

% Controllability check
Pc = ctrb(A, B);
detPc = det(Pc);

if detPc == 0
    disp('The system is not Controllable')
else
    disp('The system is Controllable')
end

% Open-loop system
sys_open = ss(A, B, C, D);
stepinfo(sys_open);

% Plot step response for open-loop system
subplot(2,2,1)
step(sys_open)
[y, t] = step(sys_open);
ss_error = 1 - y(end);
title('Step Response for Open-Loop System')

% Desired poles for closed-loop system
polDes = [-3.99+5.4578*1i; 
          -3.99-5.4578*1i; 
          -20;
          -21];

% Controller design using Ackermann's formula
K = acker(A, B, polDes);
sys_close = ss(A - B * K, B, C, D);

% Plot step response for closed-loop system
subplot(2,2,2)
step(sys_close);
title('Closed-Loop Response')

[y, t] = step(sys_close);
ss_error_cl = abs(1 - y(end));

% Design Controller with Integrator
[b, a] = ss2tf(A, B, C, 0);
[A, B, C, D] = tf2ss(b, a);

P = [0 0 0 1; 0 0 1 0; 0 1 0 0; 1 0 0 0];
Ap = inv(P) * A * P;
Bp = inv(P) * B;
Cp = C * P;

At = [Ap zeros(4,1); -Cp 0];
Bt = [Bp; 0];
Br = [zeros(4,1); 1];
Ct = [Cp 0];
% Design Controller With Integrator
polDes = [-3.99+5.4578*1i; 
          -3.99-5.4578*1i; 
          -20;
          -21;
          -22];

K = acker(At, Bt, polDes);
Aci = At - Bt * K;
sys_cl = ss(Aci, Br, Ct, 0);

% Plot step response for closed-loop system with integrator
subplot(2,2,3)
stepinfo(sys_cl)
step(sys_cl);
title('Closed-Loop Response With Integrator')

[y, t] = step(sys_cl);
ss_e_with_I = abs(1 - y(end));

% Additional plots for state variables
x0 = [1 0 0 0 0];
[y, t, x] = lsim(sys_cl, ones(size(t)), t, x0);
x1 = x(:, 1); x1_dot = x(:, 2); z = x(:, 3); z_I = x(:, 4); integral = x(:, 5);

figure
subplot(2,3,1);
plot(t, x1, '-r');
title('State Variable: x1')

subplot(2,3,2);
plot(t, x1_dot, '-bl');
title('State Variable: x1 dot')

subplot(2,3,3);
plot(t, z, '-g');
title('State Variable: z')

subplot(2,3,4);
plot(t, z_I);
title('State Variable: z with Integrator')

subplot(2,3,5);
plot(t, integral);
title('State Variable: Integrator Output')
