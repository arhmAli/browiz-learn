clear all

img=imread("img.png");
sizze=size(img);
gray=im2gray(img);
gray(1:20,:)=0;
gray(:,1:20)=0;
gray(380:400,:)=0;
gray(:,380:400)=0;
montage({img, gray});
