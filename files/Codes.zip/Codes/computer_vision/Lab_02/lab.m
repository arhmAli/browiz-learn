%imfinfo
%img to bright and dark
img=imread("wolfgang.jpg");
grey=im2gray(img);
% bw=imbinarize(grey);
bw=grey*10;
bw1=grey/10;
imwrite(bw,"wofl.jpg")
montage({bw,bw1})