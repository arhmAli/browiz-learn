data = readtable("spam_ham_dataset.csv");
X = data.text;  % 'text' column contains email content
Y = data.label_num;  % 'label_num' column contains binary labels (0 for ham, 1 for spam)

rng(30);

splitIndex = round(0.70 * size(data, 1));

X_train = X(1:splitIndex);
Y_train = Y(1:splitIndex);

X_test = X(splitIndex+1:end);
Y_test = Y(splitIndex+1:end);

% Convert table variables to cell arrays of character vectors
X_train = cellstr(X_train);
X_test = cellstr(X_test);

% Basic Text Preprocessing (lowercase and remove punctuation)
X_train = lower(X_train);
X_test = lower(X_test);
X_train = regexprep(X_train, '[^\w\s]', ' ');  % Remove punctuation (replace with space)
X_test = regexprep(X_test, '[^\w\s]', ' ');    % Remove punctuation (replace with space)

% Tokenize text into words using strsplit
X_train = strsplit(X_train);
X_test = strsplit(X_test);

% Create a vocabulary of unique words
vocabulary = unique([X_train; X_test]);

% Convert text data into binary feature vectors (presence or absence of words)
X_train = zeros(length(X_train), length(vocabulary));
X_test = zeros(length(X_test), length(vocabulary));

for i = 1:length(X_train)
    for j = 1:length(vocabulary)
        X_train(i, j) = ismember(vocabulary{j}, X_train{i});
    end
end

for i = 1:length(X_test)
    for j = 1:length(vocabulary)
        X_test(i, j) = ismember(vocabulary{j}, X_test{i});
    end
end

% Logistic Regression Model
model = fitglm(X_train, Y_train, 'Distribution', 'binomial', 'Link', 'logit');

% Predictions
pred = predict(model, X_test, 'link', 'logit');

% Model Evaluation (accuracy for binary classification)
accuracy = sum(round(pred) == Y_test) / length(Y_test);

fprintf("Accuracy of the logistic regression model: %.2f%%\n", accuracy * 100);

