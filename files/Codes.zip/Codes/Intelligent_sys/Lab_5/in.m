inp=[a,b];
fis=readfis('rule_viewer');
pred=evalfis(fis,inp)
out=res;
predi=round(pred)