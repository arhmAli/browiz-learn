a=rand(100,1);
b=rand(100,1);
res=rand(100,1);
training=[a(1:70);b(1:70);res(1:70)];
testing=[a(71:90);b(71:90);res(71:90)];
validating=[a(91:100);b(91:100);res(91:100)];
