% Load the dataset
data = readtable('survey_lung_cancer.csv');

% Encode 'GENDER' using label encoding
genderLabels = unique(data.GENDER);
genderNumeric = zeros(size(data.GENDER));
for i = 1:numel(genderLabels)
    genderNumeric(strcmp(data.GENDER, genderLabels{i})) = i;
end

% Define input features (X) and target labels (Y)
X = [genderNumeric, data.AGE, data.SMOKING, data.YELLOW_FINGERS, data.ANXIETY, ...
    data.PEER_PRESSURE, data.CHRONIC_DISEASE, data.FATIGUE, data.ALLERGY, ...
    data.WHEEZING, data.ALCOHOL_CONSUMING, data.COUGHING, ...
    data.SHORTNESS_OF_BREATH, data.SWALLOWING_DIFFICULTY, data.CHEST_PAIN];
Y = strcmp(data.LUNG_CANCER, 'YES');  % Binary labels (YES or NO)

% Split the data into training and testing sets
rng(42);  % Set random seed for reproducibility
cv = cvpartition(Y, 'HoldOut', 0.2);
X_train = X(training(cv), :);
Y_train = Y(training(cv));
X_test = X(test(cv), :);
Y_test = Y(test(cv));

% Create a feedforward neural network
net = patternnet([10 10]);  % Define a neural network with two hidden layers of 10 neurons each
net.divideParam.trainRatio = 0.8;  % Set the training ratio

% Train the neural network
[net, tr] = train(net, X_train', Y_train');

% Make predictions on the test data
Y_pred = net(X_test');

% Evaluate the model
accuracy = sum(Y_pred == Y_test) / numel(Y_test);
fprintf('Accuracy: %.2f%%\n', accuracy * 100);

% You can further evaluate the model using other metrics like ROC AUC, etc.
