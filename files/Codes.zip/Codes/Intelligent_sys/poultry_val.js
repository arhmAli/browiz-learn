const sensorVal=(temp,humid,ir_sens,fan,bulb)=>{
    if(temp>40 || humid>50){
        fan=true;
        bulb=false;
    }
    if(temp<30 || humid<40){
        fan=false;
    }
    if(ir_sens==false){
        bulb=true;
    }
}