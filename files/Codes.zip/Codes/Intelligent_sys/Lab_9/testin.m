clc;
clear all;

x1 = [1 0 1 0];
x2 = [1 1 0 0];
Yd = [0 1 1 0];

alpha = 0.5;

w13 = [0.5]; w14 = [0.9]; w23 = [0.4]; w24 = [1.0]; w35 = [-1.2]; w45 = [1.1];
theta_3 = 0.8; theta_4 = -0.1; theta_5 = 0.3;
error = 1;
esum = 1;
j = 1;
epoch = 0;

% Initialize arrays to store weights during training
w13_array = [];
w14_array = [];
w23_array = [];
w24_array = [];
w35_array = [];
w45_array = [];
err_array = [];

while error > 0.001
    e_total = 0;

    for i = 1:4
        X_1 = x1(i) * w13 + x2(i) * w23 - theta_3;
        Y_3 = 1 / (1 + exp(-X_1));

        X_2 = x1(i) * w14 + x2(i) * w24 - theta_4;
        Y_4 = 1 / (1 + exp(-X_2));

        X_5 = Y_3 * w35 + Y_4 * w45 - theta_5;
        Y_5 = 1 / (1 + exp(-X_5));

        e = Yd(i) - Y_5;
        delta_5 = Y_5 * (1 - Y_5) * e;
        delta_4 = Y_4 * (1 - Y_4) * w45 * delta_5;
        delta_3 = Y_3 * (1 - Y_3) * w35 * delta_5;

        w13 = w13 + alpha * x1(i) * delta_3;
        w14 = w14 + alpha * x1(i) * delta_4;
        w23 = w23 + alpha * x2(i) * delta_3;
        w24 = w24 + alpha * x2(i) * delta_4;
        w35 = w35 + alpha * Y_3 * delta_5;
        w45 = w45 + alpha * Y_4 * delta_5;

        theta_3 = theta_3 + alpha * -1 * delta_3;
        theta_4 = theta_4 + alpha * -1 * delta_4;
        theta_5 = theta_5 + alpha * -1 * delta_5;

        w13_array(esum) = w13;
        w14_array(esum) = w14;
        w23_array(esum) = w23;
        w24_array(esum) = w24;
        w35_array(esum) = w35;
        w45_array(esum) = w45;

        e_total = e_total + e^2;
    end

    error = e_total;
    err_array(esum) = error;
    j = j + 1;
    epoch = epoch + 1;
    esum = esum + 1;
end

disp('Final Weights and Thresholds:');
disp(['w_13: ' num2str(w13)]);
disp(['w_14: ' num2str(w14)]);
disp(['w_23: ' num2str(w23)]);
disp(['w_24: ' num2str(w24)]);
disp(['w_35: ' num2str(w35)]);
disp(['w_45: ' num2str(w45)]);
disp(['theta_3: ' num2str(theta_3)]);
disp(['theta_4: ' num2str(theta_4)]);
disp(['theta_5: ' num2str(theta_5)]);

% Plotting the variation in weights during the complete training process
figure;
plot(1:j-1, w13_array, 'b', 1:j-1, w14_array, 'g', 1:j-1, w23_array, 'r', 1:j-1, w24_array, 'c', 1:j-1, w35_array, 'm', 1:j-1, w45_array, 'y', 'LineWidth', 2)
legend('w13', 'w14', 'w23', 'w24', 'w35', 'w45');
title('Variation in weights during training process');
xlabel('Epoch');
ylabel('Weight Value');

fprintf("The number of epoch are %d\n", epoch);
figure;
t = 1:1:epoch;
plot(t, err_array, 'b', 'LineWidth', 2);
title('Graph showing variation of cost function during the training process');
xlabel('Epoch');
ylabel('Error');
