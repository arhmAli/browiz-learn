clear all;
clc
x1 = [1 0 1 0];
x2 = [1 1 0 0];
Yd = [0 1 1 0];
alpha = 0.5;

w1 = 0.5; w11 = [];
w2 = 0.9; w22 = [];
w3 = 0.4; w33 = [];
w4 = 1;   w44 = [];
w5 = -1.2; w55 = [];
w6 = 1.1; w66 = [];
t3 = 0.8; %theta 3
t4 = -0.1; %theta 4
t5 = 0.3; %theta 5

B = 0.9; % Momentum term
dw_prev = zeros(1, 6); % Initialize the previous weight updates

esum = 1;
j = 1;
epoch = 0;
alpha = 0.3; % Initial learning rate
hur = zeros(1, esum); % Initialize hur array
hueristic_counter = 1; % Initialize counter for heuristic approach

while true
    for i = 1:size(Yd)
        Y3 = 1 / (1 + exp(-(w1 * x1(i) + w3 * x2(i) - t3)));
        Y4 = 1 / (1 + exp(-(w2 * x1(i) + w4 * x2(i) - t4)));
        Y5 = 1 / (1 + exp(-(w5 * Y3 + w6 * Y4 - t5)));

        e(i) = Yd(i) - Y5;
        sig5 = Y5 * (1 - Y5) * e(i);
        sig3 = Y3 * (1 - Y3) * sig5 * w5;
        sig4 = Y4 * (1 - Y4) * w6 * sig5;

        dw1 = alpha * sig3 * x1(i) + B * dw_prev(1);
        dw2 = alpha * sig4 * x1(i) + B * dw_prev(2);
        dw3 = alpha * sig3 * x2(i) + B * dw_prev(3);
        dw4 = alpha * sig4 * x2(i) + B * dw_prev(4);
        dw5 = alpha * sig5 * Y3 + B * dw_prev(5);
        dw6 = alpha * sig5 * Y4 + B * dw_prev(6);
        dt3 = alpha * sig3 * (-1);
        dt4 = alpha * sig4 * (-1);
        dt5 = alpha * sig5 * (-1);

        w1 = w1 + dw1; w11(i, j) = w1;
        w2 = w2 + dw2; w22(i, j) = w2;
        w3 = w3 + dw3; w33(i, j) = w3;
        w4 = w4 + dw4; w44(i, j) = w4;
        w5 = w5 + dw5; w55(i, j) = w5;
        w6 = w6 + dw6; w66(i, j) = w6;

        t3 = t3 + dt3;
        t4 = t4 + dt4;
        t5 = t5 + dt5;

        dw_prev = [dw1, dw2, dw3, dw4, dw5, dw6];
    end

    err_array(esum) = rms(e);
    j = j + 1;
    epoch = epoch + 1;

    if esum > 1
        hur(esum) = err_array(esum) - err_array(esum-1);

        if hueristic_counter > 3
            if hur(esum) >= 0 && hur(esum-1) >= 0 && hur(esum-2) >= 0 && hur(esum-3) >= 0
                alpha = alpha * 1.25;
            elseif hur(esum) <= 0 && hur(esum-1) <= 0 && hur(esum-2) <= 0 && hur(esum-3) <= 0
                alpha = alpha * 1.25;
            else
                alpha = alpha / 1.25;
            end
            hueristic_counter = 1;
        end
    end

    hueristic_counter = hueristic_counter + 1;

    if err_array(esum) < 0.01
        break;
    end

    esum = esum + 1;
end

% Plotting the variation of the cost function
figure;
t = 1:1:epoch;
plot(t, err_array, 'b', 'LineWidth', 2);
title(sprintf('Graph showing variation of cost function during the training process (Alpha = %.2f)', alpha));
xlabel('Epoch');
ylabel('Error');

% Plotting the variation in weights during the complete training process
figure;
plot(1:j-1, w11(1, :), 'b', 1:j-1, w22(1, :), 'g', 1:j-1, w33(1, :), 'r', 1:j-1, w44(1, :), 'c', 1:j-1, w55(1, :), 'm', 1:j-1, w66(1, :), 'y', 'LineWidth', 2);
legend('w1', 'w2', 'w3', 'w4', 'w5', 'w6');
title('Variation in weights during training process');
xlabel('Epoch');
ylabel('Weight Value');

fprintf("The number of epochs are %d\n", epoch);
fprintf("The final learning rate is %f\n", alpha);
fprintf("The final error value is  %f\n so condition is satisfied",e );
fprintf("The number of epoch required to converge were 742 and now it is %d\n so inclusion of hueristic improved performance",epoch );
