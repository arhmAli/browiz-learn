// Make a library system to add a book and then display them 
//The books should be stored in a vector.
//Book should have title,author,year,cost

//class







//function


//main
//calling and declaring