// push,pop,front,back,size,empty
#include <iostream>
#include <string>
#include <conio.h>
using namespace std;
int main(){
    // string a;
    char a;
    cout<<"Enter"<<endl;
    // getline(cin,a);
    // a=_getch();
    cin>>a;
    cout<<a<<endl;
    return 0;
}
// getch 
// getline vs cin => it also gives spaces untill enter pressed.

// getch vs cin=> it stops immediately after typing other waits untill enter