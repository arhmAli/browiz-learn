//Associative containers
//sets,maps.deques
// less<string>
#include <iostream>
#include <set>
#include <algorithm>
#include <string>
using namespace std;
int main(){
string name[]={"arham","abba","khan","faizan","lawa"};
//by default the set assumes less so it will be arranged ascending order
auto size=sizeof(name)/sizeof(name[0]);
set<string,greater<string>>names(name,name+size);
cout<<names.size()<<endl;
names.insert("zazai");
auto i=names.begin();
// set <string,less<string>>::iterator i;

for(auto i=names.begin();i!=names.end();i++){
    cout<<*i<<endl;
    cout<<"ADRESS"<<&(*i)<<endl;
}
string searchN;
getline(cin,searchN);
// tolower(searchN);
//Implement a lowerCase function
i=names.find(searchN);
if(i==names.end()){
    cout<<"Not"<<endl;
}
else{
    cout<<"YES"<<endl;
}
return 0;
}