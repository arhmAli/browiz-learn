#include <iostream>
#include <string>
using namespace std;
class car {
private:
	int model;
	string name;
	int firstNumber;
	int secNumber;
public:
	void setModel(int d,string n) {
		model = d;
		name = n;
	}
	void showModel() {
		cout << "The model is " << model<<endl<<"while the name of the car is: "<<name<<endl;
	}
	void setNums(int a,int b) {
		firstNumber = a;
		secNumber = b;
		cout << "The sum of given nums "<<a<<" and "<<b<<" is"<< a + b << endl;
	}
};
int main() {
	car toyota, honda ,twoNums;
	toyota.setModel(2017,"XLI");
	honda.setModel(2022,"civic");
	twoNums.setNums(20, 21);
	toyota.showModel();
	honda.showModel();
	return 0;
}