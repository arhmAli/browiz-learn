import serial
import time
# from rplidar import RPLidar
# Define the serial port for communication
serial_port = 'COM5'

# Establish serial communication with the specified port
ser = serial.Serial(serial_port, baudrate=115200,timeout=1)
# 80000-125000
# ser.write(b'\xA5\x20')
# Wait for 2 seconds to allow the device to start
time.sleep(1)  # Time to start

# SYNC_BYTE = b'\xA5'
# SYNC_BYTE2 = b'\x5A'

# GET_INFO_BYTE = b'\x50'
# GET_HEALTH_BYTE = b'\x52'

# STOP_BYTE = b'\x25'
# RESET_BYTE = b'\x40'

# SCAN_BYTE = b'\x20'
# FORCE_SCAN_BYTE = b'\x21'

try:
    while True:
        # Send a command to request scan data
        ser.write(b'\xA5\x20')

        # Wait for a short time for the data to be sent
        # time.sleep(1)  # Wait for data to be sent

        # Read the incoming data
        data = ser.read(5)

        # Check if the expected number of bytes is received
        if len(data) == 5:
            # Extract and calculate quality, angle, and distance from the received data
            quality = data[0]
            angle = (data[1] + data[2] * 256) / 64.0
            distance = (data[3] + data[4] * 256) / 4.

            # Delay for 1 second before processing the next set of values
            # time.sleep(1)

            # Print the extracted values and raw data
            print(data)
            print(f"Quality: {quality}, Angle: {angle}, Distance: {distance} cm")
            if KeyboardInterrupt:
                ser.close()
                print("Program interrupted!")
                break
            

except KeyboardInterrupt:
    # Close the serial connection if the script is interrupted by the user
    # ser.write(b'\x25')
    ser.close()
    print("Program interrupted!")
