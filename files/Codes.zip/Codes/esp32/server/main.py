
from time import sleep

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 80))
s.listen(5)
tog = [1,0]


while True:
    conn, addr = s.accept()
    print('Got a connection from %s' % str(addr))
    request = conn.recv(1024)
    request = str(request)
    print('Content = >>>%s<<<' % request)

    led_on = request.find('/?led=on')
    led_off = request.find('/?led=off')
    led_blk5 = request.find('/?led=blink5')
  
    if led_on == 6:
        msg = 'LED ON'
        print(msg)
        led.value(1)
        response = msg
    
    if led_off == 6:
        msg = 'LED OFF'
        print(msg)
        led.value(0)
        response = msg

    if led_blk5 == 6:
        msg = 'LED BLINK'
        print(msg)
        for i in range(5):
            print('current pin value: {}'.format(led.value()))
            led.value(tog[led.value()])
            sleep(1)
        response = msg
