import requests

url = "http://127.0.0.1/?led=blink5"

payload={}
headers = {}
response = requests.request("GET", url, headers=headers, data=payload)
print(response)