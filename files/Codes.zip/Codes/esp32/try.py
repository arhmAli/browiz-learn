from rplidar import RPLidar

PORT_NAME = 'COM5'  
lidar = RPLidar(PORT_NAME)

try:
    info = lidar.get_info()
    print(info)
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    lidar.disconnect()

import rospy as rp
from serialmsgs.msg import LaserScan
from std_msgs.msg import String

def lid_data(data):
    lst=data.ranges
    arr=[]
    for i in lst:
        if i<=1:
            arr.append(i)
            print("Obstacle detected at {} angle".format(i))
            motor("clockwise")
print("There are {} obstacles in the way".format(len(arr)))
rp.node_init('lidar_data',LaserScan)
rp.Subscriber('/scan',LaserScan,lid_data)

def motor(dir):
    ros_control_motor_str=String()
    ros_control_motor_str.data=dir
    motor_pub.publish(motor_str)
rp.node_init('motor')
rp.Subscriber('/scan',LaserScan,lid_data)
motor_pub=rp.Publisher('/motor',String,queue_size=10)
rp.spin()