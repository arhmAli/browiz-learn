% Task: 01 - e^n
n = -5:1:5;
x1 = exp(n);
subplot(3, 2, 1);
stem(n, x1, 'LineWidth', 2);
title('Plot of e^n');

% Task: 02 - e^-n
x2 = exp(-n);
subplot(3, 2, 2);
stem(n, x2, 'LineWidth', 2);
title('Plot of e^{-n}');

% Task: 03 - Discrete Complex Exponential Signals
% e^jwn
n = -5:1:5;
w = 0.5; 
x3 = exp(1i*w*n);
subplot(3, 2, 3);
stem(n, real(x3), 'r', 'LineWidth', 2);
hold on;
stem(n, imag(x3), 'b', 'LineWidth', 2);
title('Real and Imaginary parts of e^{jwn}');
legend('Real Part', 'Imaginary Part');

% e^-jwn
x4 = exp(-1i*w*n);
subplot(3, 2, 4);
stem(n, real(x4), 'r', 'LineWidth', 2);
hold on;
stem(n, imag(x4), 'b', 'LineWidth', 2);
title('Real and Imaginary parts of e^{-jwn}');
legend('Real Part', 'Imaginary Part');

% Complex
x5 = exp(1i*w*n) + exp(-1i*w*n);
subplot(3, 2, 5);
stem(n, real(x5), 'r', 'LineWidth', 2);
hold on;
stem(n, imag(x5), 'b', 'LineWidth', 2);
title('Real and Imaginary parts of Complex Exponential');
legend('Real Part', 'Imaginary Part');
