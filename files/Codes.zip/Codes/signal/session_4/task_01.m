% implement for e^-jt and e^jt and then for complex exponential signals for step impulse and ramp signal and plot in 3d all graphs axis=>imaginary , time 
% plot for the function e^t,e^-t,e^jt and e^-jt for step input ramp input and impulse input
% Task: 01 - e^t
% Step Input
t_step = -5:0.01:5;
u_step = 1*(t_step>=0);
subplot(3, 1, 1);
plot(t_step, u_step, 'LineWidth', 2);
title('Step Input');
xlabel('Time');
ylabel('Amplitude');

% Ramp Input
t_ramp = -5:0.01:5;
ramp_input = t_ramp.*(t_ramp>=0);
subplot(3, 1, 2);
plot(t_ramp, ramp_input, 'LineWidth', 2);
title('Ramp Input');
xlabel('Time');
ylabel('Amplitude');

% Impulse Input
t_impulse = -5:0.01:5;
y_impulse = (t_impulse==0);
subplot(3, 1, 3);
stem(t_impulse, y_impulse, 'LineWidth', 2);
title('Impulse Input');
xlabel('Time');
ylabel('Amplitude');

% Task: 03 - Complex Exponential Signals
% e^-jt
t = -5:0.01:5;
u = 1.*(t>=0);
x3 = exp(-1i*t).*u;
figure;
subplot(2,1,2)
plot(t, real(x3), 'LineWidth', 2);
title('Real part of e^-jt with Step Impulse');
xlabel('Time');
ylabel('Amplitude');

subplot(2,1,1);
plot(t, imag(x3), 'LineWidth', 2);
title('Imaginary part of e^-jt with Step Impulse');
xlabel('Time');
ylabel('Amplitude');

% e^jt
t = -5:0.01:5;
u = 1.*(t>=0);
x4 = exp(1i*t).*u;
subplot(2,2,1);
plot(t, real(x4), 'LineWidth', 2);
title('Real part of e^jt with Step Impulse');
xlabel('Time');
ylabel('Amplitude');

subplot(2,2,4);
plot(t, imag(x4), 'LineWidth', 2);
title('Imaginary part of e^jt with Step Impulse');
xlabel('Time');
ylabel('Amplitude');

% Task: 01 - e^t
t = -5:0.01:5;
u = 1.*(t>=0);
x1 = exp(t).*u;
figure;
plot3(t, real(x1), imag(x1), 'LineWidth', 2);
title('3D Plot of e^t with Step Impulse');
xlabel('Time');
ylabel('Real Axis');
zlabel('Imaginary Axis');

% Task: 02 - e^-t
t = -5:0.01:5;
u = 1.*(t>=0);
x2 = exp(-t).*u;
figure;
plot3(t, real(x2), imag(x2), 'LineWidth', 2);
title('3D Plot of e^-t with Step Impulse');
xlabel('Time');
ylabel('Real Axis');
zlabel('Imaginary Axis');

% Task: 03 - Complex Exponential Signals
% e^-jt
t = -5:0.01:5;
u = 1.*(t>=0);
x3 = exp(-1i*t).*u;
figure;
plot3(t, real(x3), imag(x3), 'LineWidth', 2);
title('3D Plot of e^-jt with Step Impulse');
xlabel('Time');
ylabel('Real Axis');
zlabel('Imaginary Axis');

% e^jt
t = -5:0.01:5;
u = 1.*(t>=0);
x4 = exp(1i*t).*u;
figure;
plot3(t, real(x4), imag(x4), 'LineWidth', 2);
title('3D Plot of e^jt with Step Impulse');
xlabel('Time');
ylabel('Real Axis');
zlabel('Imaginary Axis');
% 
% now implement for discrete signals
% e^n
% e^-n
% e^jwn
% e^-jwn
% and complex