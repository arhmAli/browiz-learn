    % implement all these with given functions and do time shifting 
    % 
    % for unit impulse
    % t=-5:0.01:5;
    % y=dirac(t);
    % idx=y=Inf
    % y(idx)=1
    % plot(t,y)
    % delta(t)/delta[n]t/n
    % delta(t-1)/delta[n-1]
    % delta(t+4)/dekta[n+3]
    % 
    % now for unit step
    % t=>same
    % y=heaviside(t)
    % plot(t,y)
    % =>u(t)/u[n]
    % =>u(t-1)/u[n-1]
    % =>u(u+4)/u[n+3]
    % 
    % now for unit ramp
    % t=same
    % y=t
    % plot(t,y)
    % r(t)/r[n]
    % r(t+2)/r[n+2]
    % r(t+2)/r[n+2]
    % r(t+3)/r[n+3]
    % 
    % now unit rectangular fun
    % t=
    % rect=(t>=(-1/2))
    % -(t>=(1/2))
    % plot(t,rect)
    % same shifted recatgular function
    % 
    % unit triangular function
    % t
    % tr=(t+1).*(t>=1).*(t<0)+(-t_1).*(t>=0).*(t<1)
    % plot(t,tri)
    % shifted triangular function
    % 
    % signum function
    % t=
    % sig_num=1*(t>0)-1*(t<0)+0*(t==0)
    % plot(t,sig_num)
    x(t)=2r(t)+3r(t-2)-10r(t-5)+5r(t-7) plot x(t) x_dot(t) x_ddot(t) versus t
% Unit Impulse
figure;
t = -5:0.01:5;
y1 = dirac(t);
idx = find(y1 == Inf);
y1(idx) = 1;
subplot(3, 2, 1);
plot(t, y1, 'LineWidth', 2);
title('Continuous Unit Impulse Signal (delta(t))');

n = -5:5;
y2 = [zeros(1,5), 1, zeros(1,5)];
subplot(3, 2, 2);
stem(n, y2, 'LineWidth', 2);
title('Discrete Unit Impulse Signal (delta[n])');

y3 = dirac(t-1);
idx = find(y3 == Inf);
y3(idx) = 1;
subplot(3, 2, 3);
plot(t, y3, 'LineWidth', 2);
title('Delta Function with Time Shift (delta(t-1))');

y4 = dirac(t+4);
idx = find(y4 == Inf);
y4(idx) = 1;
subplot(3, 2, 4);
plot(t, y4, 'LineWidth', 2);
title('Delta Function with Time Shift (delta(t+4))');

% Unit Step
figure;
y5 = heaviside(t);
subplot(3, 2, 1);
plot(t, y5, 'LineWidth', 2);
title('Continuous Unit Step Signal (u(t))');

u = heaviside(n);
subplot(3, 2, 2);
stem(n, u, 'LineWidth', 2);
title('Discrete Unit Step Signal (u[n])');

u_shifted = heaviside(t-1);
subplot(3, 2, 3);
plot(t, u_shifted, 'LineWidth', 2);
title('Unit Step Function with Time Shift (u(t-1))');

u_shifted_2 = heaviside(t+4);
subplot(3, 2, 4);
plot(t, u_shifted_2, 'LineWidth', 2);
title('Unit Step Function with Time Shift (u(t+4))');

% Unit Ramp
y6 = t .* heaviside(t);
subplot(3, 2, 5);
plot(t, y6, 'LineWidth', 2);
title('Continuous Unit Ramp Signal (r(t))');

ramp = n .* u;
subplot(3, 2, 6);
stem(n, ramp, 'LineWidth', 2);
title('Discrete Unit Ramp Signal (r[n])');
figure
ramp_shifted = (t-2) .* heaviside(t-2);
% subplot(3, 2, 7);
subplot(2,2,1)
plot(t, ramp_shifted, 'LineWidth', 2);
title('Unit Ramp Function with Time Shift (r(t-2))');
subplot(2,2,2)
ramp_shifted_2 = (t+3) .* heaviside(t+3);
% subplot(3, 2, 8);
plot(t, ramp_shifted_2, 'LineWidth', 2);
title('Unit Ramp Function with Time Shift (r(t+3))');

% Unit Rectangular Function and Triangular Function
figure;
rect = (t >= -0.5) - (t >= 0.5);
subplot(3, 2, 1);
plot(t, rect, 'LineWidth', 2);
title('Continuous Unit Rectangular Function');

rect_shifted = (t-1 >= -0.5) - (t-1 >= 0.5);
subplot(3, 2, 2);
plot(t, rect_shifted, 'LineWidth', 2);
title('Shifted Unit Rectangular Function');

tri = (t+1) .* ((t>=-1) & (t<0)) + (-t+1) .* ((t>=0) & (t<1));
subplot(3, 2, 3);
plot(t, tri, 'LineWidth', 2);
title('Continuous Unit Triangular Function');

tri_shifted = (t-2+1) .* ((t-2>=-1) & (t-2<0)) + (-(t-2)+1) .* ((t-2>=0) & (t-2<1));
subplot(3, 2, 4);
plot(t, tri_shifted, 'LineWidth', 2);
title('Shifted Unit Triangular Function');

% Signum Function
sig_num = 1*(t>0) - 1*(t<0);
subplot(3, 2, 5);
plot(t, sig_num, 'LineWidth', 2);
title('Continuous Signum Function');

sig_num_shifted = 1*(t-1>0) - 1*(t-1<0);
subplot(3, 2, 6);
plot(t, sig_num_shifted, 'LineWidth', 2);
title('Signum Function with Time Shift (sig_num(t-1))');
