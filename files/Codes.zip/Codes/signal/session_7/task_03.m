% simulation of convolution
clear all;
clc;
t=-400:400;
X=zeros(1,length(t));
x1=-150;
x2=150;
H=zeros(1,length(t));
h1=-50;
h2=50;
Y=zeros(1,length(t));
xh1=x1+h1;
xh2=x2+h2;
x=sin(pi*t/10)./(pi*t/10);
x(t==0)=1;
h=t./t;
h(t==0)=1;
H(t>=h1 & t<=h2)=h(t>=h1 & t<=h2);
X(t>=x1 & t<=x2)=x(t>=x1 & t<=x2);
figure(4)
subplot(2,2,1);
plot(t,x);
grid on ;
grid minor;
xlabel('time(s)');
ylabel('x(t)');
title('function x(t)');
subplot(2,2,2);
plot(t,H);
grid on ;
grid minor;
xlabel('time(s)');
ylabel('h(t)');
title('function h(t)');
for n=xh1:xh2
    f=fliplr(X);
  Xm=circshift(f,[0,n]);
  m=Xm.*H;
  Y(t==n)=sum(m);
  figure(5);
  subplot(2,2,1);
 plot(t,H,'r',t,circshift(fliplr(X),[0,n]),'b','LineWidth',3);
title('Convlution process : 1.Flip , 2.Shift , 3.Multiply , 4.Sum','FontWeight','b','FontSize',15);
 grid on ;
 grid minor;
  subplot(2,1,2);
 plot(t,Y,'k','LineWidth',3);
title('Convlution Output :' ,'FontWeight','b','FontSize',15);
pause(0.01);
sgtitle('Illustration of 1d convolution','Fontweight','b','FontSize',15)
fig=gcf;
fig.Units='normalized';
fig.OuterPosition=[0 0 1 1];
end
