clc;
clear all;
close all;
clearvars;
%% Task:2 convolution of moisy signal with step signal
w=1;
t=0:0.0001:1;
x=sin(2*pi*w*t)+0.2*rand(1,length(t));
h=ones(1,40);
y=conv(x,h);

figure(3);
subplot(2,2,1);
plot(t,x);
grid on ;
grid minor;
xlabel('time(s)');
ylabel('x(t)');
title('function x(t)');

subplot(2,2,2);
plot(h)
grid on ;
grid minor;
xlabel('time(s)');
ylabel('h(t)');
title('function h(t)');

subplot(2,2,[3 4]);
plot(y)
grid on ;
grid minor;
xlabel('time(s)');
ylabel('y(t)');
title('function y(t)');
title('convolution of two functions using convolution function ');
