clc;
clear all;
close all;
clearvars;
x=input('Enter x[n]:')
h=input('Enter h[n]:')
lx=length(x);
lh=length(h);
X=[x zeros(1,lh)];
H=[h zeros(1,lx)];
for i=1:lh+lx-1;
    Y(i)=0;
    for j=1:lx
        if(i-j+1>0)
            Y(i)=Y(i)+X(j)*H(i-j+1);
        end
    end
end
figure(1);
subplot(2,2,1);
stem(X)
grid on :
grid minor;
xlabel('n');
ylabel('x[n]');
title('function x[n]');

subplot(2,2,2);
stem(H)
grid on :
grid minor;
xlabel('n');
ylabel('h[n]');
title('function h[n]');

subplot(2,2,[3 4]);
stem(Y)
grid on :
grid minor;
xlabel('n');
ylabel('y[n]');
title('convolution of two functions without using convolution function ');