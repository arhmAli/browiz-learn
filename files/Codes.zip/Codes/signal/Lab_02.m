% Variable transformation
% Variable reversal
% Phase shift or Shifting
% Scaling
t = -5:0.01:5;
x = sin(2 * pi * t);

% Amplitude Reversal
amplitudeReversal = -x;

% Time Shift
t_shifted = t + 2;

% Amplitude Shift
x_amplitude_shifted = x + 0.5;

% Time Scaling
t_scaled = t * 0.5;

% Amplitude Scaling
x_scaled = x * 2;

% Create a single figure with 2x3 subplots
figure;

% Subplot 1: Original Signal
subplot(2, 3, 1);
plot(t, x);
title('Original Signal');
xlabel('Time');
ylabel('Amplitude');

% Subplot 2: Amplitude Reversal
subplot(2, 3, 2);
plot(t, amplitudeReversal);
title('Amplitude-Reversed Signal');
xlabel('Time');
ylabel('Amplitude');

% Subplot 3: Time Shift
subplot(2, 3, 3);
plot(t_shifted, x);
title('Time-Shifted Signal');
xlabel('Time');
ylabel('Amplitude');

% Subplot 4: Amplitude Shift
subplot(2, 3, 4);
plot(t, x_amplitude_shifted);
title('Amplitude-Shifted Signal');
xlabel('Time');
ylabel('Amplitude');

% Subplot 5: Time Scaling
subplot(2, 3, 5);
plot(t_scaled, x);
title('Time Scaled Signal');
xlabel('Time');
ylabel('Amplitude');

% Subplot 6: Amplitude Scaling
subplot(2, 3, 6);
plot(t, x_scaled);
title('Amplitude Scaled Signal');
xlabel('Time');
ylabel('Amplitude');

% Adjust the layout
sgtitle('Signal Operations');

% % Task 1:
% % Discrete Signal
% n = -5:5;
% fun = cos((pi/8) * n);
% 
% % Task 2:
% % Time reversal (Discrete)
% n_reverse = fliplr(n);
% fun_rev = cos( (pi/8) * n_reverse);
% 
% % Task 3:
% % Phase shift (Discrete)
% phi = 2; % Phase shift value
% fun_shifted = cos((pi/8)* (n - phi));
% 
% % Task 4:
% % Scaling (Discrete)
% scale_factor = 0.5;
% fun_scaled = scale_factor * (cos((pi/8)* n));
% 
% % Create a single figure with 1x3 layout
% figure('Position', [100, 100, 1200, 400]);
% 
% % First subplot (1x4 arrangement)
% subplot(1, 7, 1);
% stem(n, fun, 'b', 'LineWidth', 2);
% xlabel('n')
% ylabel('Amplitude')
% title('Original Signal')
% ylim([-1, 1]);
% 
% % Second subplot for time reversal (1x4 arrangement)
% subplot(1, 7, 2);
% stem(n_reverse, fun_rev, 'r', 'LineWidth', 2);
% xlabel('n')
% ylabel('Amplitude')
% title('Reversed Signal')
% ylim([-1, 1]);
% 
% subplot(1, 7, 3);
% stem(n, fun_shifted, 'g', 'LineWidth', 2);
% xlabel('n')
% ylabel('Amplitude')
% title('Phase-Shifted Signal')
% ylim([-1, 1]);
% 
% % Third subplot for scaled signal (1x4 arrangement)
% subplot(1, 7, [4, 5]);
% stem(n, fun_scaled, 'm', 'LineWidth', 2);
% xlabel('n')
% ylabel('Amplitude')
% title('Scaled Signal')
% ylim([-1, 1]);
% 
% % Create an empty subplot to make space for the legend
% subplot(1, 7, [6, 7]);
% axis off;
% 
% % Add a legend to the second subplot
% legend({'Original', 'Reversed', 'Phase-Shifted', 'Scaled'}, 'Location', 'southoutside', 'Orientation', 'horizontal');

% x(n)=2*cos((pi/4)*n)+sin((pi/8)*n)-2*cos((pi/2))+pi/6
% there should be 6 subplots
% 1st cos((pi/4)*n)
% 2nd 2*cos((pi/4)*n)
% 3rd sin((pi/8)*n)
% 4th cos((pi/2)
% 5th cos((pi/2))+pi/6
% 6th 2*cos((pi/2))+pi/6
% Define the range of n (assuming a reasonable range)
% n = 0:99;
% 
% % Calculate the signals
% x1 = cos((pi/4)*n);
% x2 = 2 * cos((pi/4)*n);
% x3 = sin((pi/8)*n);
% x4 = cos(pi/2) * ones(size(n));
% x5 = (cos(pi/2) + pi/6) * ones(size(n));
% x6 = (2 * cos(pi/2) + pi/6) * ones(size(n));
% 
% % Integrate the signals using the cumulative sum
% integrated_x1 = cumsum(x1);
% integrated_x2 = cumsum(x2);
% integrated_x3 = cumsum(x3);
% integrated_x4 = cumsum(x4);
% integrated_x5 = cumsum(x5);
% integrated_x6 = cumsum(x6);
% 
% % Combine 2nd, 3rd, and 6th signals
% combined_signal = x2 + x3 + x6;
% 
% % Display specific information
% subplot(3, 2, 1);
% plot(n, x1);
% title('cos((pi/4)*n)');
% 
% subplot(3, 2, 2);
% plot(n, x2);
% title('2*cos((pi/4)*n)');
% 
% subplot(3, 2, 3);
% plot(n, x3);
% title('sin((pi/8)*n)');
% 
% subplot(3, 2, 4);
% plot(n, x4);
% title('cos((pi/2))');
% 
% subplot(3, 2, 5);
% plot(n, x5);
% title('cos((pi/2))+pi/6');
% 
% subplot(3, 2, 6);
% plot(n, x6);
% title('2*cos((pi/2))+pi/6');
% 
% % Display integrated signals
% figure;
% subplot(3, 2, 1);
% plot(n, integrated_x1);
% title('Integrated cos((pi/4)*n)');
% 
% subplot(3, 2, 2);
% plot(n, integrated_x2);
% title('Integrated 2*cos((pi/4)*n)');
% 
% subplot(3, 2, 3);
% plot(n, integrated_x3);
% title('Integrated sin((pi/8)*n)');
% 
% subplot(3, 2, 4);
% plot(n, integrated_x4);
% title('Integrated cos((pi/2))');
% 
% subplot(3, 2, 5);
% plot(n, integrated_x5);
% title('Integrated cos((pi/2))+pi/6');
% 
% subplot(3, 2, 6);
% plot(n, integrated_x6);
% title('Integrated 2*cos((pi/2))+pi/6');
% 
% % Display the combined signal
% figure;
% plot(n, combined_signal);
% title('Combined 2nd, 3rd, and 6th Signals');
