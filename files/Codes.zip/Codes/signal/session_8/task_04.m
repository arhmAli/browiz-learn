clear all;
clc;
T = 2;
t = 0:0.01:T;
x1(t<=T/2)=2;
x1(t>=T/2 & t<=T)=-2;
plot(t,x1,'Linewidth',5)
hold on
w = (2*pi)/T;
grid on
x2(t<=T/2)=-1/2;
x2(t>=T/2 & t<=T)=1/2;
plot(t,x2,'Linewidth',5)
x = x1 + x2;
N = 10;
for n=0:N
    a(n+N+1) = (1/T)*sum(x.*exp(-i*w*n*t));
    a1(n+N+1) = (1/T)*sum(x1.*exp(-i*w*n*t));
    a2(n+N+1) = (1/T)*sum(x2.*exp(-i*w*n*t));
a=a1+a2;
end