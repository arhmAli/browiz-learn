%% lab 08 task 08  Conjugate symmetry
clear all
clc;
clf;
close all;
T=10;
t=0:.01:T;
w=2*pi/T;
x=1*exp(-i*5*t); 
plot(t,real(x),"LineWidth",2,"Color",'k')
grid on 
hold on
xc=1*exp(i*5*t);
plot(t,real(xc),"LineWidth",2,"Color",'r')
N=100;
for n=-N:N
    a(N+n+1)=(1/T)*sum(x.*exp(-i*2*n*t*w));
    a1(N+n+1)=(1/T)*sum(x.*exp(i*2*n*t*w));
end