clc;
clear all;
n = 0:1:40;
a = 3;  
b = -2; 
x1 = (cos(2*pi*0.2*n)).*(cos(2*pi*0.2*(n-1)));  
x2 = (sin(2*pi*0.2*n)).*(sin(2*pi*0.2*(n-1)));  
x = a*x1 + b*x2;
num = [2.2403 2.24908 2.2403];
den = [1 -0.4 0.75];
initial_c = [0 0];
y1 = filter(num, den, x1, initial_c);
y2 = filter(num, den, x2, initial_c);
y = filter(num, den, x, initial_c);
yt = a*y1 + b*y2;
d = y - yt;

subplot(3,2,1)
stem(n, y)
xlabel('Discrete Time Index n');
ylabel('Amplitude');
title('Response of input multiplication & scaling')

subplot(3,2,2)
stem(n, yt)
xlabel('Discrete Time Index n');
ylabel('Amplitude');
title('Response of Output multiplication & scaling')

subplot(3,2,3)
stem(n, d)
xlabel('Discrete Time Index n');
ylabel('Amplitude');
title('Difference Signal')
