t = 1:0.001:10;
x = @(t) sin(t) .* (t >= 0) + 2 * (t < 0);

num_terms = 8;  

xt = zeros(size(t));

figure;

for k = 1:num_terms
    xk = (4/((2*k-1)*pi)) * sin((2*k-1)*pi/2*t);
    xt = xt + xk;
    
    subplot(num_terms+1,1,k)
    plot(t, xt);
    grid on
    title(['Sum of first ', num2str(k), ' terms'])
end

subplot(num_terms+1,1,num_terms+1)
plot(t, x(t));
grid on
title('Original Function')
