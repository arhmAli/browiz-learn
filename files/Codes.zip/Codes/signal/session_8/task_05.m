% Clear workspace and command window
clear all;
clc;

% Define parameters
T = 2;
t = 0:0.01:T;

% Generate original signal x(t)
x(t<=T/2) = 2;
x(t>=T/2 & t<=T) = -2;

% Plot original signal x(t)
plot(t, x, 'Linewidth', 3);
hold on;

% Angular frequency for Fourier series
w = (2*pi)/T;

% Set grid on for better visualization
grid on;

% Shift the time axis for the second plot
to = 2;
t_shifted = 0 + to:0.01:T + to;

% Generate shifted signal x(t + 2)
x(t_shifted<=T/2) = 2;
x(t_shifted>=T/2 & t_shifted<=T) = -2;

% Plot shifted signal x(t + 2)
plot(t_shifted, x, 'Linewidth', 3);

N = 10;

% Initialize array to store Fourier series coefficients
a = zeros(1, 2*N+1);

% Compute Fourier series coefficients
for n = 0:N
    a(n+N+1) = (1/T) * sum(x .* exp(-1i*w*n*t));
end
figure;
plot(-N:N, abs(a), 'Linewidth', 2);
title('Magnitude Spectrum of Fourier Coefficients');
xlabel('n');
ylabel('|a(n + N + 1)|');
grid on;
