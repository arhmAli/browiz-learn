T = 2;
t = 0:0.01:T;
x(t<=T/2)=1/2;
x(t>=T/2 & t<=T)=-1/2;
plot(t,x,'Linewidth',3)
x1=fliplr(x)
hold on
grid on
plot(-t,x1,'Linewidth',3)
N=50;
for n=-N:N
a(n+N+1) = (1/T)*sum(x.*exp(-i*2*n*pi*t/T));
a1(n+N+1) = (1/T)*sum(x.*exp(-i*2*n*pi*t/T));
end
title('Original Signal and Its Time-Reversed Version');
