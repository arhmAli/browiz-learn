clc;
clear all;
t = 1:0.001:10;
x = @(t) sin(t) .* (t >= 0) + 2 * (t < 0);
x_For = 1/2 * ones(1, length(t));
for i = 1:5  
    x_For = x_For - (1 / (i * pi)) * ((exp(1i * i * t) - exp(-1i * i * t)) / (2 * 1i));
     subplot(5+1,1,i)
    plot(t, x_For);
    grid on
    title(['Sum of first ', num2str(i), ' terms'])
end

for i = 6:100
    x_For = x_For - (1 / (i * pi)) * ((exp(1i * i * t) - exp(-1i * i * t)) / (2 * 1i));
end

figure;
subplot(2,1,1)
plot(t, x(t));
title('Original Function');
grid on

subplot(2,1,2)
plot(t, real(x_For)); 
title('Fourier Series Approximation');
xlim([min(t),5])
grid on
