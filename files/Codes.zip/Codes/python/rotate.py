def rot(k,arr):
    lst=[]
    for i in range (k):
        last_elm=arr.pop(-1)
        arr.insert(0,last_elm)
    return print(arr)

rot(3,[1,2,3,4,5,6])


