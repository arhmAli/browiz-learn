import cv2 as cv
import numpy as np

image=cv.imread('dog.jpg',cv.IMREAD_GRAYSCALE)
threshold=128
ret,thresh1=cv.threshold(image,threshold,255,cv.THRESH_BINARY)
cv.imshow('asd',image)
cv.imshow('dsa',thresh1)
cv.waitKey(0)
cv.destroyAllWindows()

# cv.imshow('Dog',image)
# gray=cv.cvtColor(image,cv.COLOR_BGR2GRAY)
# print("Orignal image")
# print(image.shape)
# print("Gray image")
# print(gray.shape)
